(function ($) {
    $(document).ready(function () {
        $(document).ajaxComplete(function (event, request, settings) {

        });
    });
})(jQuery);
